//Middlewares
var Campground = require('../models/campgrounds');
var Comment = require('../models/comment');
var middlewareObj = {};

//middleware for checking campgound owner
middlewareObj.checkOwner = function(req, res, next) {
        if (req.isAuthenticated()) {
            Campground.findById(req.params.id, (err, foundCampground) => {
                if (err) {
                    req.flash('error', "campground not found");
                    res.redirect('/campgrounds');
                } else {
                    if (foundCampground.author.id.equals(req.user._id) || req.user.isAdmin) {
                        next();
                    } else {
                        req.flash('error', 'you dont have permission to do that.')
                        res.redirect('/campgrounds');
                    }
                }
            });
        } else {
            req.flash('error', 'you need to be logged in');
            res.redirect('back');
        }
    }
    //check comment owner
middlewareObj.checkCommentOwner = function(req, res, next) {
        if (req.isAuthenticated()) {
            Comment.findById(req.params.comment_id, (err, foundComment) => {
                if (err) {
                    res.redirect('/campgrounds');
                } else {
                    if (foundComment.author.id.equals(req.user._id) || req.user.isAdmin) {
                        next();
                    } else {
                        req.flash('error', 'you dont have persmission to do that')
                        res.redirect('back');
                    }
                }
            });
        } else {
            req.flash('error', 'please login!')
            res.redirect('back');
        }
    }
    //check if user is logged in
middlewareObj.isLoggedIn = function(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    } else {
        req.flash('error', "you need to be logged in to do that!");
        res.redirect('/login');
    }
}






module.exports = middlewareObj;