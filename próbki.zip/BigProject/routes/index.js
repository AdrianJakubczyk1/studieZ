var express = require('express');
var router = express.Router();
var passport = require('passport');
var User = require('../models/user');
var Campground = require('../models/campgrounds');
var async = require('async');
var nodemailer = require('nodemailer');
var crypto = require('crypto');
var xoauth2 = require('xoauth2');

router.get('/register', (req, res) => {
    res.render('register');
});


router.post('/register', (req, res) => {
    var newUser = new User({
        username: req.body.username,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        avatar: req.body.avatar,
        email: req.body.email
    });
    if (req.body.adminCode === '123456789') {
        newUser.isAdmin = true;
    }

    User.register(newUser, req.body.password, (err, user) => {
        if (err) {
            req.flash('error', err.message);
            return res.redirect('/register');
        } else {
            passport.authenticate('local')(req, res, () => {
                req.flash('success', 'Welcome ' + user.username);
                res.redirect('/campgrounds');
            });
        }
    });
});

//show login form
router.get('/login', (req, res) => {
    res.render('login');
});

//login logic
router.post('/login',
    passport.authenticate('local', {
        successRedirect: '/campgrounds',
        failureRedirect: '/login',
        failureFlash: 'invalid username or password',
        successFlash: 'successfuly logged in!'
    })
);


//logout
router.get('/logout', (req, res) => {
    req.logout();
    req.flash('success', 'logged out')
    res.redirect('/campgrounds');
});

router.get('/forgot', function(req, res) {
    res.render('users/forgot');
});

router.post('/forgot', (req, res, next) => {
    async.waterfall([
            function(done) {
                crypto.randomBytes(20, (err, buf) => {
                    var token = buf.toString('hex');
                    console.log(token);
                    done(err, token);
                })
            },
            function(token, done) {
                User.findOne({ email: req.body.email }, (err, user) => {
                    if (!user) {
                        req.flash('error', 'No account with that email address exists');
                        return res.redirect('/forgot');
                    }
                    user.resetPasswordToken = token;
                    user.resetPasswordExpires = Date.now() + 3600000;

                    user.save((err) => {
                        done(err, token, user);
                    });
                });
            },
            function(token, user, done) {
                var smtpTransport = nodemailer.createTransport({
                    host: 'smtp.gmail.com',

                    secure: true,
                    auth: {
                        type: 'OAuth2',
                        user: 'jakubczykadrian882@gmail.com',
                        clientId: '345216320687-l84sapqq5slvquk7qh0bujp2p5r6bm1n.apps.googleusercontent.com',
                        clientSecret: 'u3nDjOptqjmlq96xavnxOMnI',
                        refreshToken: "1/Flgm7fX7Uo1xjGGpfLRIsDguHB6UAU8WT1HUN_ytdBQ",
                        access_token: "ya29.GlsJBxiFi0g_4v82WyZY6VVNH9XqsAio0YYvcvB3h9MH2fIf11EHbV36t1araC9LSfKFAtwJpLzU2HAZuBlNHEYVL7W-82xqPTXtE-gfiKzOCiXSTFjnsSfMkCeh"

                    }
                });

                //pass: process.env.GMAILPW



                var mailOptions = {
                    to: user.email,
                    from: 'jakubczykadrian882@gmail.com',
                    subject: 'Node.js Password Reset',
                    text: 'You are receiving this beacuse , you have requested an password reset please click on following link' +
                        ' or paste it into your browser to complete the reset ' +
                        'http://' + req.headers.host + '/reset/' + token + '\n\n' +
                        'If you did not request this, please ignore this email and your password will remain unchanged.\n'
                };
                smtpTransport.sendMail(mailOptions, (err) => {
                    console.log('mail sent');
                    req.flash('success', 'An email has been sent to ' + user.email + ' with further instructions')
                    done(err, 'done')
                });
            }
        ],
        (err) => {
            if (err)
                return next(err);
            res.redirect('/forgot');
        });
});

router.get('/reset/:token', (req, res) => {
    User.findOne({ resetPasswordToken: req.params.token, }, (err, user) => {
        if (!user) {
            req.flash('error', 'Password reset token is invalid or has expired.');
            return res.redirect('/forgot');
        }
        res.render('users/reset', { token: req.params.token });
    });
});

router.post('/reset/:token', (req, res) => {
    async.waterfall([
            function(done) {
                User.findOne({ resetPasswordToken: req.params.token, resetPasswordExpires: { $gt: Date.now() } }, function(err, user) {
                    if (!user) {
                        req.flash('error', 'Password reset token is invalid or has expired.');
                        return res.redirect('back');
                    }
                    if (req.body.password === req.body.confirm) {
                        user.setPassword(req.body.password, function(err) {
                            user.resetPasswordToken = undefined;
                            user.resetPasswordExpires = undefined;

                            user.save(function(err) {
                                req.logIn(user, function(err) {
                                    done(err, user);
                                });
                            });
                        });
                    } else {
                        req.flash("error", "Passwords do not match.");
                        return res.redirect('back');
                    }
                });
            },
            function(user, done) {
                var smtpTransport = nodemailer.createTransport({
                    host: 'smtp.gmail.com',

                    secure: true,
                    auth: {
                        type: 'OAuth2',
                        user: 'jakubczykadrian882@gmail.com',
                        clientId: '345216320687-l84sapqq5slvquk7qh0bujp2p5r6bm1n.apps.googleusercontent.com',
                        clientSecret: 'u3nDjOptqjmlq96xavnxOMnI',
                        refreshToken: "1/Flgm7fX7Uo1xjGGpfLRIsDguHB6UAU8WT1HUN_ytdBQ",
                        access_token: "ya29.GlsJBxiFi0g_4v82WyZY6VVNH9XqsAio0YYvcvB3h9MH2fIf11EHbV36t1araC9LSfKFAtwJpLzU2HAZuBlNHEYVL7W-82xqPTXtE-gfiKzOCiXSTFjnsSfMkCeh"
                    }
                });
                var mailOptions = {
                    to: user.email,
                    from: 'jakubczykadrian882@gmail.com',
                    subject: 'Your password has been changed',
                    text: 'Hello,\n\n' +
                        'This is a confirmation that the password for your account ' + user.email + ' has just been changed.\n'
                };
                smtpTransport.sendMail(mailOptions, function(err) {
                    if (err) req.flash('error', 'something went wrong')
                    req.flash('success', 'Success! Your password has been changed.');
                    done(err);
                });
            }
        ],
        function(err) {
            if (err) req.flash('error', 'something went wrong');
            res.redirect('/campgrounds');
        });
});


router.get("/", (req, res) => {
    res.render('landing');
});

//User profiles
router.get('/users/:id', (req, res) => {
    User.findById(req.params.id, (err, foundUser) => {
        if (err) {
            req.flash('error', "Something went wrong");
            res.redirect('back');
        } else {
            Campground.find().where('author.id').equals(foundUser._id).exec((err, campgrounds) => {
                if (err) {
                    req.flash('error', "Something went wrong");
                    res.redirect('back');
                }
                res.render('users/show', { user: foundUser, campgrounds: campgrounds });
            });

        }
    });
});

function isLoggedIn(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    } else {
        res.redirect('/login');
    }
}

module.exports = router;