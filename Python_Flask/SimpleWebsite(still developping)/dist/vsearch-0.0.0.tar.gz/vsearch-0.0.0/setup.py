from setuptools import setup
setup(
    name='vsearch',
    py_modules = ['vsearch'],
    )
    
